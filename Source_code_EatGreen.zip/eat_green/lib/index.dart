// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/register/register_widget.dart' show RegisterWidget;
export '/question_pages/question1/question1_widget.dart' show Question1Widget;
export '/question_pages/question2/question2_widget.dart' show Question2Widget;
export '/question_pages/question3/question3_widget.dart' show Question3Widget;
export '/question_pages/question4/question4_widget.dart' show Question4Widget;
export '/question_pages/question5/question5_widget.dart' show Question5Widget;
export '/question_pages/question9/question9_widget.dart' show Question9Widget;
export '/question_pages/question7/question7_widget.dart' show Question7Widget;
export '/question_pages/question8/question8_widget.dart' show Question8Widget;
export '/question_pages/question6/question6_widget.dart' show Question6Widget;
export '/setting/setting/setting_widget.dart' show SettingWidget;
export '/setting/profile/profile_widget.dart' show ProfileWidget;
export '/setting/language/language_widget.dart' show LanguageWidget;
export '/setting/feedback/feedback_widget.dart' show FeedbackWidget;
export '/setting/premium/premium_widget.dart' show PremiumWidget;
export '/activities/list_activities/list_activities_widget.dart'
    show ListActivitiesWidget;
export '/pages/dashboardv2/dashboardv2_widget.dart' show Dashboardv2Widget;
export '/menu/show_item/show_item_widget.dart' show ShowItemWidget;
export '/menu/list_items/list_items_widget.dart' show ListItemsWidget;
export '/activities/show_activity/show_activity_widget.dart'
    show ShowActivityWidget;
export '/menu/menu_main/menu_main_widget.dart' show MenuMainWidget;
export '/activities/a_c_tmain/a_c_tmain_widget.dart' show ACTmainWidget;
export '/pages/welcome/welcome_widget.dart' show WelcomeWidget;
export '/pages/forgot_password/forgot_password_widget.dart'
    show ForgotPasswordWidget;
export '/setting/rating_page/rating_page_widget.dart' show RatingPageWidget;
export '/question_pages/language_op/language_op_widget.dart'
    show LanguageOpWidget;
export '/setting/about_us/about_us_widget.dart' show AboutUsWidget;
export '/question_pages/get_started/get_started_widget.dart'
    show GetStartedWidget;
export '/setting/mo_mo_payment/mo_mo_payment_widget.dart'
    show MoMoPaymentWidget;
export '/setting/mo_mo_terms/mo_mo_terms_widget.dart' show MoMoTermsWidget;
export '/setting/bank_terms/bank_terms_widget.dart' show BankTermsWidget;
export '/setting/bank_choice/bank_choice_widget.dart' show BankChoiceWidget;
export '/setting/b_i_d_v_payment/b_i_d_v_payment_widget.dart'
    show BIDVPaymentWidget;
export '/setting/m_b_payment/m_b_payment_widget.dart' show MBPaymentWidget;
export '/setting/support/support_widget.dart' show SupportWidget;
export '/setting/supportemail/supportemail_widget.dart' show SupportemailWidget;
