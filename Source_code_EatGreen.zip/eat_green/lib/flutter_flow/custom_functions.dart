import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

bool ageCheck(int age) {
  if (age < 8 || age > 150) {
    return false;
  } else {
    return true;
  }
  // check if age is above 7 and below 150
}

bool weightCheck(int weight) {
  if (weight <= 10 || weight >= 300) {
    return false;
  } else {
    return true;
  }
}

bool heightCheck(int height) {
  if (height <= 30 || height >= 300) {
    return false;
  } else {
    return true;
  }
}

double? cal(
  double? minutes,
  double? calories,
  double? totalcalories,
  double? hours,
) {
  totalcalories = ((hours ?? 0) * 60 + (minutes ?? 0)) * (calories ?? 0);
  return totalcalories;
}

double? calitem(
  double? calories,
  double? count,
  double? totalcalories,
) {
  totalcalories = (calories ?? 0) * (count ?? 0);
  return totalcalories;
}

double? percentage(
  double? totalcalories,
  double? breakfast,
  double? percentagee,
) {
  percentagee = (totalcalories ?? 0) / (breakfast ?? 0);
  return percentagee;
}

String? quoteGenerator() {
  // create a function generate random quotes
  List<String> quotes = [
    "The greatest glory in living lies not in never falling, but in rising every time we fall. -Nelson Mandela",
    "The way to get started is to quit talking and begin doing. -Walt Disney",
    "Your time is limited, don't waste it living someone else's life. -Steve Jobs",
    "If life were predictable it would cease to be life, and be without flavor. -Eleanor Roosevelt",
    "If you look at what you have in life, you'll always have more. If you look at what you don't have in life, you'll never have enough. -Oprah Winfrey",
    "If you set your goals ridiculously high and it's a failure, you will fail above everyone else's success. -James Cameron",
    "Life is what happens when you're busy making other plans. -John Lennon",
    "Spread love everywhere you go. Let no one ever come to you without leaving happier. -Mother Teresa",
    "When you reach the end of your rope, tie a knot in it and hang on. -Franklin D. Roosevelt",
    "The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart. -Helen Keller",
  ];
  return quotes[math.Random().nextInt(quotes.length)];
}

double sumitem(List<double> listprice) {
  var total = 0.0;
  List<double> list = [];
  list.addAll(listprice);
  for (var i = 0; i < list.length; i++) {
    total += list[i];
  }
  return total;
}

double? percentagemenumain(
  double? result,
  double? calories,
  double? lunch,
) {
  result = (calories ?? 0) / (lunch ?? 0) * 100;
  return result;
}

double? customCaloriesWidgetFunction(
  double calories,
  double? totalcalories,
) {
  if (totalcalories == null) {
    totalcalories = 1600;
  } else if (totalcalories == 0) {
    return 0;
  } else {
    return (calories / totalcalories) * 300;
  }
}
