import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'vi'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? viText = '',
  }) =>
      [enText, viText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // Login
  {
    'lggig3y3': {
      'en': 'Get Started',
      'vi': 'Hãy bắt đầu',
    },
    '19v64tur': {
      'en': 'Let\'s get started by filling out the form below.',
      'vi': 'Hãy khởi động bằng việc điền biểu mẫu này.',
    },
    'mqo9e0jg': {
      'en': 'Email',
      'vi': 'Email',
    },
    's7prb308': {
      'en': 'Password',
      'vi': 'Mật khẩu',
    },
    '08lvssy3': {
      'en': 'Login',
      'vi': 'Đăng nhập',
    },
    'k2dchkj0': {
      'en': 'Or sign up with',
      'vi': 'Các kiểu đăng nhập khác',
    },
    'hkktjh1t': {
      'en': 'Continue with Google',
      'vi': 'Đăng nhập bằng Google',
    },
    '94vobv00': {
      'en': 'Continue with Apple',
      'vi': 'Đăng nhập bằng Apple',
    },
    'd43q875k': {
      'en': 'Don\'t have an account?  ',
      'vi': 'Chưa có tài khoản?',
    },
    'io0cjzrx': {
      'en': 'Sign Up here',
      'vi': 'Đăng ký tại đây',
    },
    'sofltz68': {
      'en': 'Forget password?',
      'vi': 'Quên mật khẩu',
    },
    'yl3c7f87': {
      'en': 'Click here',
      'vi': 'Nhấn tại đây',
    },
    '4ozc797c': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Register
  {
    '33kbuvus': {
      'en': 'Create an account',
      'vi': 'Đăng ký tài khoản',
    },
    '46ciin11': {
      'en': 'Let\'s get started by filling out the form below.',
      'vi': 'Hãy khởi động bằng việc điền biểu mẫu này.',
    },
    'rdxe5q5j': {
      'en': 'Email',
      'vi': 'Email',
    },
    'p20s1qkb': {
      'en': 'Password',
      'vi': 'Mật khẩu',
    },
    'kw61iouw': {
      'en': 'Confirm Password',
      'vi': 'Nhắc lại mật khẩu',
    },
    'josdl6ry': {
      'en': 'Create Account',
      'vi': 'Tạo tài khoản',
    },
    'uu1yu2qd': {
      'en': 'Already have an account? ',
      'vi': 'Đã có tài khoản?',
    },
    '5697vxke': {
      'en': 'Sign In here',
      'vi': 'Đăng nhập tại đây',
    },
    'kbzy0zv4': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question1
  {
    'g585x5vk': {
      'en': 'What is your age?',
      'vi': 'Bạn bao nhiêu tuổi?',
    },
    'evk1q5ux': {
      'en': 'Type here',
      'vi': 'Nhập ở đây',
    },
    'jztulvp5': {
      'en': 'Field is required',
      'vi': 'Lĩnh vực được yêu cầu',
    },
    'suafiihl': {
      'en': 'There must be something wrong in your form! Please check again',
      'vi':
          'Phải có một cái gì đó sai trong hình thức của bạn! Vui lòng kiểm tra lại',
    },
    'gdy5q801': {
      'en': 'Please choose an option from the dropdown',
      'vi': 'Vui lòng chọn một tùy chọn từ danh sách thả xuống',
    },
    '45mxuu5v': {
      'en': 'Next',
      'vi': 'Kế tiếp',
    },
    'b1y05m8c': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    'q474n25i': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question2
  {
    'foavm1qu': {
      'en': 'What is your biological sex?',
      'vi': 'Giới tính sinh học',
    },
    '27nqxvj7': {
      'en': 'Male',
      'vi': 'Nam',
    },
    '39wbitbd': {
      'en': 'Female',
      'vi': 'Nữ',
    },
    '58mnqift': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    'ljnnbsi7': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question3
  {
    '8efeial9': {
      'en': 'How much do you weight? (in kg)',
      'vi': 'Nhập chỉ số cân nặng của bạn (kg)',
    },
    't3fdn0y5': {
      'en': 'Type here...',
      'vi': 'Nhập tại đây....',
    },
    'p8qq2lap': {
      'en': 'Field is required',
      'vi': 'Biểu mẫu bắt buộc',
    },
    'ojgf87fu': {
      'en': 'Please choose an option from the dropdown',
      'vi': 'Please choose an option from the dropdown',
    },
    'fbc7azzi': {
      'en': 'Next',
      'vi': 'Tiếp theo',
    },
    '8ju6e4q3': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    '1nte1juj': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question4
  {
    'tv2r4tid': {
      'en': 'How tall are you? (in cm)',
      'vi': 'Nhập chỉ số chiều cao của bạn (cm)',
    },
    '4v1fsqpi': {
      'en': 'Type here...',
      'vi': 'Nhập tại đây....',
    },
    't7jgoxat': {
      'en': 'Field is required',
      'vi': 'Biểu mẫu bắt buộc',
    },
    'yxz550sv': {
      'en': 'Please choose an option from the dropdown',
      'vi': 'Please choose an option from the dropdown',
    },
    'plmxbwez': {
      'en': 'Next',
      'vi': 'Tiếp theo',
    },
    'mb9zv5z2': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    'qbc9d0f1': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question5
  {
    '25lvib9a': {
      'en': 'What is your favorite kind of menu ?',
      'vi': 'Loại thực đơn yêu thích của bạn là gì',
    },
    'zk6y44kk': {
      'en': 'European',
      'vi': 'Châu Âu',
    },
    'kx2m1k66': {
      'en': 'Asian',
      'vi': 'Châu Á',
    },
    '5k6eznka': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    'a0pavtr4': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question9
  {
    'ed8zs7ov': {
      'en': 'What is your goal?',
      'vi': 'Mục tiêu của bạn là gì',
    },
    'l3wggcv3': {
      'en': 'Lose weight',
      'vi': 'Giảm cân',
    },
    'nhpyvhhl': {
      'en': 'Gain weight',
      'vi': 'Tăng cân',
    },
    'unuys1c8': {
      'en': 'Maintain weight',
      'vi': 'Giữ cân',
    },
    '0rzkpk15': {
      'en': 'Build muscle',
      'vi': 'Tăng cường cơ bắp',
    },
    'jcsrtb39': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    '1majgv0k': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question7
  {
    'otdfx2ro': {
      'en': 'How active are you?',
      'vi': 'Bạn hoạt động như thế nào?',
    },
    'wg25dprc': {
      'en': 'Lightly active. Mostly sitting. Ex: office worker',
      'vi': 'Hoạt động nhẹ nhàng. Chủ yếu là ngồi. Ví dụ: nhân viên văn phòng',
    },
    'tgdvbbga': {
      'en': 'Moderately active.Mostly standing . Ex: teachers',
      'vi': 'Hoạt động vừa phải. Chủ yếu là đứng . Ví dụ: giáo viên',
    },
    'gk10t6hz': {
      'en': 'Active. Mostly working. Ex: restaurant worker',
      'vi': 'Tích cực. Chủ yếu là làm việc. Ví dụ: nhân viên nhà hàng',
    },
    'q1z4uj6o': {
      'en': 'Very active. Physically demanding. Ex: builder',
      'vi': 'Rất tích cực. Đòi hỏi thể chất. Ví dụ: thợ xây',
    },
    'ph7svsgn': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    'ytawc63f': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question8
  {
    'w2s5ewiz': {
      'en': 'How is your weekly routine?',
      'vi': 'Thói quen hàng tuần của bạn như thế nào?',
    },
    'pitkldnl': {
      'en': 'Light (1 - 3 hours of gentle to moderate exercise)',
      'vi': 'Nhẹ (1 - 3 giờ tập thể dục nhẹ nhàng đến trung bình)',
    },
    '7cmrmtxd': {
      'en': 'Moderate (3-4 hours of moderate exercise)',
      'vi': 'Trung bình (3-4 giờ tập thể dục vừa phải)',
    },
    'idzejzj3': {
      'en': 'Intense (4-6 hours of moderate to hardcore exercises)',
      'vi': 'Cường độ cao (4-6 giờ tập luyện từ trung bình đến nặng)',
    },
    'swcsiba8': {
      'en': 'Very intense (7+ hours of hardcore training)',
      'vi': 'Rất căng thẳng (hơn 7 giờ luyện tập cường độ cao)',
    },
    'eqyb7aun': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    'wu6al3uy': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Question6
  {
    'h1vtm40r': {
      'en': 'What is your specific diet?',
      'vi': 'Chế độ ăn uống cụ thể của bạn là gì?',
    },
    'qrnnmrgy': {
      'en': 'Classic',
      'vi': 'Bình thường',
    },
    'st533o4v': {
      'en': 'Vegan',
      'vi': 'Thuần chay',
    },
    't9ica981': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    'p87rb61q': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Setting
  {
    '6mtzduv0': {
      'en': 'Setting',
      'vi': 'Cài đặt',
    },
    'c2tq2478': {
      'en': 'Switch to Dark Mode',
      'vi': 'Chuyển sang Chế độ tối',
    },
    '3uypy0jw': {
      'en': 'Switch to Light Mode',
      'vi': 'Chuyển sang Chế độ ánh sáng',
    },
    '0qccmj9i': {
      'en': 'Account Settings',
      'vi': 'Cài đặt tài khoản',
    },
    'cz2motwm': {
      'en': 'Edit Profile',
      'vi': 'Chỉnh sửa hồ sơ',
    },
    'yzu14lhy': {
      'en': 'Language',
      'vi': 'Ngôn ngữ',
    },
    'gl9jby49': {
      'en': 'About us and contact support',
      'vi': 'Về chúng tôi và hỗ trợ',
    },
    'aen29yb5': {
      'en': 'Premium',
      'vi': 'Gói ưu đãi',
    },
    '3so99f5f': {
      'en': 'Rating',
      'vi': 'Xếp hạng',
    },
    'geak7fnc': {
      'en': 'Feedback',
      'vi': 'Nhận xét',
    },
    'ytvl2n9m': {
      'en': 'Log Out',
      'vi': 'Đăng xuất',
    },
    '7m37zubb': {
      'en': '__',
      'vi': '__',
    },
  },
  // profile
  {
    'llr66147': {
      'en': 'UserID',
      'vi': '',
    },
    '0hwkidxh': {
      'en': 'Asian',
      'vi': 'Châu Á',
    },
    'd8p3cmlm': {
      'en': 'Asian',
      'vi': 'Châu Á',
    },
    's678yfuu': {
      'en': 'European',
      'vi': 'Châu Âu',
    },
    'hdyifjmo': {
      'en': 'Biological Sex',
      'vi': 'giới tính sinh học',
    },
    'nere62zz': {
      'en': 'Male',
      'vi': 'Nam giới',
    },
    'heogl68b': {
      'en': 'Male',
      'vi': 'Nam giới',
    },
    '1lo64uw5': {
      'en': 'Female',
      'vi': 'Nữ giới',
    },
    '7hfnic9r': {
      'en': 'Biological Sex',
      'vi': 'giới tính sinh học',
    },
    'elg7fy5i': {
      'en': 'Classic',
      'vi': 'Bình thường',
    },
    'v6izx3fg': {
      'en': 'Classic',
      'vi': 'Bình thường',
    },
    'efd349pb': {
      'en': 'Vegan',
      'vi': 'Thuần chay',
    },
    '7xubix2p': {
      'en': 'Diet type',
      'vi': 'loại chế độ ăn kiêng',
    },
    'ufk71kvg': {
      'en': 'Save Changes',
      'vi': 'Lưu thay đổi',
    },
    'x74b18q5': {
      'en': 'Edit your profile',
      'vi': 'Chỉnh sửa hồ sơ của bạn',
    },
  },
  // language
  {
    '8gh4r7xn': {
      'en': 'Vietnamese',
      'vi': 'Tiếng Việt',
    },
    'h4i6lzbz': {
      'en': 'English',
      'vi': 'Tiếng Anh',
    },
    'de96z9z7': {
      'en': 'Language',
      'vi': 'Ngôn ngữ',
    },
    'tgk860rm': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Feedback
  {
    '5vurpwte': {
      'en': 'If you have additional feedback. \nPlease type here',
      'vi': 'Nếu bạn có phản hồi bổ sung.\nVui lòng nhập vào đây',
    },
    '6x84pory': {
      'en': 'Submit',
      'vi': 'Nộp',
    },
    '3qg8xsp9': {
      'en': 'Feedback',
      'vi': 'Nhận xét',
    },
    'xmg4xx8l': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Premium
  {
    'eer79azj': {
      'en': 'We will accompany you \nto the day you reach your dream',
      'vi':
          'Chúng tôi sẽ đồng hành cùng bạn\ncho đến ngày bạn đạt được ước mơ của mình',
    },
    'z9a6k2og': {
      'en': 'Activate to get the best result \nwith more benefits',
      'vi': 'Kích hoạt để có kết quả tốt nhất\nvới nhiều lợi ích hơn',
    },
    'gbo2wsf9': {
      'en': 'Best values',
      'vi': 'Giá trị tốt nhất',
    },
    '5hzh4dbz': {
      'en': '1  month',
      'vi': '1 tháng',
    },
    'stfh59hx': {
      'en': '20.000 VND',
      'vi': '20.000 VNĐ',
    },
    'iculmoie': {
      'en': '3 months',
      'vi': '3 tháng',
    },
    'nsit2z8q': {
      'en': '50.000 VND',
      'vi': '50.000 VNĐ',
    },
    'sipysuw7': {
      'en': '6 months',
      'vi': '6 tháng',
    },
    '1oimmocq': {
      'en': '90.000 VND',
      'vi': '90.000 VNĐ',
    },
    '89qi4opw': {
      'en': 'No ads',
      'vi': 'Không quảng cáo',
    },
    '5g95uvxp': {
      'en': 'Meal Customization',
      'vi': 'Tùy chỉnh bữa ăn',
    },
    'rjkpzwn9': {
      'en': 'Follow till the end of the month to \nclaim vouchers',
      'vi': 'Theo dõi đến cuối tháng để\nnhận phiếu giảm giá',
    },
    'ai6trf9r': {
      'en': 'Early access to new feautures',
      'vi': 'Truy cập sớm vào các tính năng mới',
    },
    '1z25ji9m': {
      'en': 'Subcribe now with Paypal ',
      'vi': 'Đăng ký ngay bây giờ với Paypal',
    },
    'qz74iyv2': {
      'en': 'Subcribe now with MoMo',
      'vi': 'Đăng ký ngay bây giờ với MoMo',
    },
    'q90yphxz': {
      'en': 'Subcribe now with bank transfer',
      'vi': 'Đăng ký ngay bây giờ qua chuyển khoản',
    },
    'yc3uc6h3': {
      'en': 'Have troubles with the subcription?\nClick here for support',
      'vi': 'Gặp vấn đề với đăng ký gói?\nNhấn vào đây để được hỗ trợ',
    },
    '3t3d39g5': {
      'en': 'Premium',
      'vi': 'Gói đăng kí',
    },
    '6ytx66lk': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // ListActivities
  {
    'mx0vu3r3': {
      'en': 'Search activities here...',
      'vi': 'Hoạt động tìm kiếm tại đây...',
    },
    '6x6xduba': {
      'en': 'Option 1',
      'vi': 'lựa chọn 1',
    },
    '332ai85p': {
      'en': 'Search result',
      'vi': 'Tìm kêt quả',
    },
    '9s0xqy1c': {
      'en': 'Activities',
      'vi': 'Các hoạt động',
    },
    't85x711d': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // dashboardv2
  {
    '55nxilzz': {
      'en': 'Dashboard',
      'vi': 'Trang chính',
    },
    '34as36ct': {
      'en': 'Sleep time',
      'vi': 'Thời gian ngủ',
    },
    'h2t4pd2v': {
      'en': 'Exercise time',
      'vi': 'Thời gian tập thể thao',
    },
    'zet25kvr': {
      'en': 'Calories',
      'vi': 'Calories',
    },
    'm2mpbry8': {
      'en': 'Protein',
      'vi': 'Protein',
    },
    '5382dmox': {
      'en': 'Carbs',
      'vi': 'Carbs',
    },
    '1g2g1ino': {
      'en': 'Fat',
      'vi': 'Fat',
    },
    'i3b1s82k': {
      'en': 'Water',
      'vi': 'Nước',
    },
    'aygaf8yp': {
      'en': 'Water',
      'vi': 'Nước',
    },
    '8ozaurmm': {
      'en': 'Goal: 2.0 L',
      'vi': 'Goal: 2.0 L',
    },
    'oa67sgwd': {
      'en': ' L',
      'vi': ' L',
    },
    '3efe59hf': {
      'en': 'Home',
      'vi': '',
    },
  },
  // ShowItem
  {
    'sqrlv8p0': {
      'en': 'Carlories:',
      'vi': 'Carlories:',
    },
    't8om1zxs': {
      'en': 'Carbonhydrate:',
      'vi': 'cacbonhydrat:',
    },
    'zeuvgvl7': {
      'en': 'g',
      'vi': 'g',
    },
    'tohmcje0': {
      'en': 'Protein:',
      'vi': 'Protein:',
    },
    '3vnidhpj': {
      'en': 'g',
      'vi': 'g',
    },
    'edacf7ug': {
      'en': 'Fat:',
      'vi': 'Fat:',
    },
    'el96oyzs': {
      'en': 'g',
      'vi': 'g',
    },
    'n62vu5v7': {
      'en': 'Add to list',
      'vi': 'Thêm vào',
    },
    '64csr9dl': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // ListItems
  {
    '8ju7cq08': {
      'en': 'Search items here...',
      'vi': 'Tra cứu tại đây',
    },
    'oow246wn': {
      'en': 'Option 1',
      'vi': 'Option 1',
    },
    '3viwq2lg': {
      'en': 'Search result',
      'vi': 'Kết quả',
    },
    'n8el621t': {
      'en': 'Add',
      'vi': 'Thêm',
    },
    '6q6tkm9m': {
      'en': 'Items',
      'vi': 'Items',
    },
    'bef0giym': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // ShowActivity
  {
    'me2e4syk': {
      'en': 'Carlories:',
      'vi': 'Carlories:',
    },
    '02hb3wjp': {
      'en': '/min',
      'vi': '/phút',
    },
    '0s4s1vxk': {
      'en': 'Enter hours here',
      'vi': 'Nhập số giờ ở đây',
    },
    'mvke4xu1': {
      'en': 'Enter minutes here',
      'vi': 'Nhập số phút ở đây',
    },
    'dutqxq5y': {
      'en': 'Total carlories:',
      'vi': 'Total carlories:',
    },
    '9j1msn0u': {
      'en': 'Add',
      'vi': 'Thêm',
    },
    '0m6pxjaw': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // MenuMain
  {
    '8vw1xvfh': {
      'en': 'Custom Menu',
      'vi': 'Thực đơn tùy chỉnh',
    },
    'eptdnx9x': {
      'en': 'Breakfast',
      'vi': 'Bữa sáng',
    },
    'scj69ox2': {
      'en': 'Lunch',
      'vi': 'Bữa sáng',
    },
    'rdilw3to': {
      'en': '50%',
      'vi': '50%',
    },
    '22e6ywln': {
      'en': 'Dessert',
      'vi': 'Bữa sáng',
    },
    'x5atq3vy': {
      'en': '50%',
      'vi': '50%',
    },
    'oawryjmt': {
      'en': 'Dinner',
      'vi': 'Bữa sáng',
    },
    '5kirccsh': {
      'en': '50%',
      'vi': '50%',
    },
    'w0o71ovb': {
      'en': 'Menu',
      'vi': 'Thực đơn',
    },
    '7himsdd9': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // ACTmain
  {
    '23r5k5fj': {
      'en': 'Weight(kg)',
      'vi': 'Cân nặng(kg)',
    },
    'z3yvx4lr': {
      'en': 'Activities',
      'vi': 'Hoạt động',
    },
    'cggolcx3': {
      'en': 'Notification activities',
      'vi': 'Thông báo hoạt động',
    },
    'gpnrfxey': {
      'en': 'Activities',
      'vi': 'Hoạt động',
    },
    'mkzclkqt': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // Welcome
  {
    'vsfn1oqa': {
      'en': 'Welcome!',
      'vi': 'Chào mừng',
    },
    'jnib4ml5': {
      'en':
          'Lets get started on your journey!\n\n\"The journey of a thousand miles begins with a single step.\" - Lao Tzu',
      'vi':
          'Hãy bắt đầu hành trình của bạn!\n\n\"Mọi cuộc hành trình ngàn dặm đều bắt đầu từ bước đầu tiên\" - Lao Tzu',
    },
    'ka8qsybm': {
      'en': 'Next',
      'vi': 'Tiếp theo',
    },
    'emqctkr9': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // forgotPassword
  {
    '43ia3wh4': {
      'en': 'Forgot Password',
      'vi': 'Quên mật khẩu',
    },
    '7w49h3x2': {
      'en':
          'We will send you an email with a link to reset your password, please enter the email associated with your account below.',
      'vi':
          'Chúng tôi sẽ gửi cho bạn một email có liên kết để đặt lại mật khẩu của bạn, vui lòng nhập email được liên kết với tài khoản của bạn bên dưới.',
    },
    'qd7plnzx': {
      'en': 'Type here...',
      'vi': 'Nhập ở đây...',
    },
    'lk4c2sky': {
      'en': 'Field is required',
      'vi': 'Lĩnh vực được yêu cầu',
    },
    'nj3jjy6q': {
      'en': 'Please choose an option from the dropdown',
      'vi': 'Vui lòng chọn một tùy chọn từ danh sách thả xuống',
    },
    'scgwae9r': {
      'en': 'Submit',
      'vi': 'Nộp',
    },
    'xfiybhga': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // RatingPage
  {
    '5useilwj': {
      'en': 'Please rate our service',
      'vi': 'Vui lòng đánh giá dịch vụ của chúng tôi',
    },
    'ufao2of4': {
      'en': 'Submit',
      'vi': 'Nộp',
    },
    'i5yxieth': {
      'en': 'Rating',
      'vi': 'Đánh giá',
    },
    'eid7sbp1': {
      'en': 'Home',
      'vi': '',
    },
  },
  // LanguageOp
  {
    'quvej69g': {
      'en': 'Choose your language',
      'vi': 'Chọn ngôn ngữ của bạn',
    },
    '63rio3i4': {
      'en': 'English',
      'vi': 'Tiếng Anh',
    },
    'ns5jwwh1': {
      'en': 'Vietnamese',
      'vi': 'Tiếng Việt',
    },
    'bwetx52b': {
      'en': '@eatgreen.com.vn',
      'vi': '@eatgreen.com.vn',
    },
    '7cmx1tit': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // AboutUs
  {
    '3gq1ecu6': {
      'en': 'Visit our Facebook page',
      'vi': 'Trang Facebook của chúng tôi',
    },
    'kl656aj5': {
      'en': 'Visit our Instagram',
      'vi': 'Trang Instagram của chúng tôi',
    },
    'mj316w17': {
      'en': 'Contact support',
      'vi': 'Liên hệ hỗ trợ',
    },
    '2n0erz8f': {
      'en': 'About us and contact support',
      'vi': 'Về chúng tôi và hỗ trợ',
    },
    'xt1lbwk0': {
      'en': 'Home',
      'vi': '',
    },
  },
  // GetStarted
  {
    'tcqjt0e4': {
      'en': 'Welcome!',
      'vi': 'Chào mừng',
    },
    '888xxcd6': {
      'en': 'Next',
      'vi': 'Tiếp theo',
    },
    'dpty26qx': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // MoMoPayment
  {
    'xup37845': {
      'en': 'Important notes in subcribing premium using MoMo',
      'vi': 'Những lưu ý quan trọng khi đăng ký premium bằng MoMo',
    },
    'a14jjt3w': {
      'en':
          ' 1. The content of transcation should be as the following:\n\n [gmail] - [subcription type] \n Ex: abc@gmail.com - 1 month',
      'vi':
          ' 1. Nội dung chuyển tiền phải theo mẫu như sau:\n\n [gmail người dùng] - [gói đăng ký]\n Ví dụ: abc@gmail.com - 1 tháng',
    },
    'gh17qzfx': {
      'en':
          ' 2.Please ensure that you enter the correct amount when \nmaking a payment. \nThis will help to avoid any delays in\nprocessing your payment and returning any changes.\n1 month - 20000 VND/3 months - 50000 VND\n6 months - 90000 VND',
      'vi':
          '2.Hãy đảm bảo rằng bạn nhập đúng số \ntiền khi thanh toán.\nĐiều này sẽ giúp tránh bất kỳ sự chậm trễ trong \nxử lý thanh toán của bạn\nvà trả lại tiền thừa .\n1 tháng - 20000đ/3 tháng - 50000đ\n6 tháng - 90000 VNĐ',
    },
    'fdf040i6': {
      'en':
          'EatGreen\'s MoMo subcription payment terms and condition.\nBy using this payment you agree to our terms and condition.',
      'vi':
          'Điều khoản và điều kiện thanh toán đăng ký MoMo của EatGreen.\n\nBằng cách sử dụng khoản thanh toán này, bạn đồng ý với các điều khoản và điều kiện của chúng tôi.',
    },
    'ldo3ssoj': {
      'en': 'MoMo Payment',
      'vi': 'Thanh toán qua MoMo',
    },
    '2mskgnab': {
      'en': 'Home',
      'vi': '',
    },
  },
  // MoMoTerms
  {
    'p7glno4v': {
      'en': 'Terms and Conditons',
      'vi': 'Điều khoản và Điều kiện',
    },
    '2hl2bks4': {
      'en':
          '1. The premium status will be activated within 12 hours to 1 working day after a successful MoMo purchase.\nPlease note that this timeframe is an estimate and may vary depending on various factors, including server load and payment processing times.',
      'vi':
          '1. Gói đăng ký sẽ được kích hoạt trong vòng từ 12 giờ đến 1 ngày làm việc sau khi thanh toán bằng MoMo thành công.\nXin lưu ý rằng khung thời gian này là ước tính và có thể thay đổi tùy thuộc vào các yếu tố khác nhau, bao gồm thời gian xử lý thanh toán và kĩ thuật.',
    },
    'nr7elsm1': {
      'en':
          '2.Purchase Amount Accuracy:\n\nIt is essential to enter the correct amount of money for the purchase.\nIn case of any discrepancy between the entered amount and the actual payment received, the difference will be processed within 1-2 working days.\nWe recommend double-checking the entered amount to avoid delays in processing.',
      'vi':
          'Nhập chính xác số tiền cần thanh tóan\nKhách hàng lưu ý cần nhập vừa đủ và chính xác số tiền trong mỗi lần thanh toán.\nNếu có bất kỳ sự khác biệt nào giữa số tiền đã nhập và khoản thanh toán thực tế, số tiền chênh lệch sẽ được xử lý và hoàn trả trong vòng 1-2 ngày làm việc.\nChúng tôi khuyên bạn nên kiểm tra kỹ số tiền đã nhập để tránh trường hợp bị chậm trễ trong quá trình xử lý.',
    },
    'mzu1o089': {
      'en':
          '3.Refunds:\n\nRefunds  are not currently available once a transaction is successfully processed.\nPlease ensure that you review your purchase carefully before proceeding.',
      'vi':
          '3. Hoàn tiền và Hủy gói:\n\nViệc hoàn tiền  không khả dụng sau khi giao dịch được xử lý thành công.\nVui lòng đảm bảo rằng bạn xem xét kỹ giao dịch mua của mình trước khi tiếp tục.',
    },
    'dqq2vm4s': {
      'en':
          '4.Support and Assistance:\n\nIf you encounter any issues with your premium status activation or payment processing, please contact our support team via quangatse161692@fpt.edu.vn or 0775092217.\nOur team will strive to assist you and resolve any problems in a timely manner.',
      'vi':
          '4.Hỗ trợ khách hàng:\n\nNếu bạn gặp bất kỳ vấn đề nào với việc kích hoạt gói đăng ký hoặc quá trình thanh toán, vui lòng liên hệ với nhóm hỗ trợ của chúng tôi qua quangatse161692@fpt.edu.vn or 0775092217.\nNhóm của chúng tôi sẽ cố gắng hỗ trợ bạn và giải quyết mọi vấn đề một cách kịp thời.',
    },
    'nvj4ikfz': {
      'en':
          '5.Terms and Conditions Updates:\n\nThese terms and conditions are subject to change without prior notice.\nPlease refer to the latest version available on our website or within the app for the most up-to-date information.',
      'vi':
          '5.Cập nhật Điều khoản và Điều kiện:\n\nCác điều khoản và điều kiện này có thể thay đổi mà không cần thông báo trước.\nVui lòng tham khảo phiên bản mới nhất hiện có của chúng tôi hoặc trong ứng dụng để biết thông tin cập nhật sớm nhất.',
    },
    '10ltsnvv': {
      'en': 'Terms and conditions',
      'vi': 'Điều khoản và điều kiện chuyển tiền qua MoMo',
    },
    'ggd4xu70': {
      'en': 'Home',
      'vi': '',
    },
  },
  // BankTerms
  {
    '9ar2h4un': {
      'en': 'Terms and Conditons',
      'vi': 'Điều khoản và Điều kiện',
    },
    's85779q7': {
      'en':
          '1. The premium status will be activated within 12 hours to 1 working day after a successful bank transfer purchase.\nPlease note that this timeframe is an estimate and may vary depending on various factors, including server load and payment processing times.',
      'vi':
          '1. Gói đăng ký sẽ được kích hoạt trong vòng từ 12 giờ đến 1 ngày làm việc sau khi thanh toán bằng thẻ ngân hàng thành công.\nXin lưu ý rằng khung thời gian này là ước tính và có thể thay đổi tùy thuộc vào các yếu tố khác nhau, bao gồm thời gian xử lý thanh toán và kĩ thuật.',
    },
    'jalm6t7t': {
      'en':
          '2.Purchase Amount Accuracy:\n\nIt is essential to enter the correct amount of money and the transfer content for the purchase.\nIn case of any discrepancy between the entered amount and the actual payment received, the difference will be processed within 1-2 working days.\nWe recommend double-checking the entered amount and tranfer content to avoid delays in processing.',
      'vi':
          'Nhập chính xác số tiền cần thanh tóan\nKhách hàng lưu ý cần nhập vừa đủ, chính xác số tiền và nội dung chuyển khoản trong mỗi lần thanh toán.\nNếu có bất kỳ sự khác biệt nào giữa số tiền đã nhập và khoản thanh toán thực tế, số tiền chênh lệch sẽ được xử lý và hoàn trả trong vòng 1-2 ngày làm việc.\nChúng tôi khuyên bạn nên kiểm tra kỹ số tiền và nội dung chuyển khoản đã nhập để tránh trường hợp bị chậm trễ trong quá trình xử lý.',
    },
    'u2fvongd': {
      'en':
          '3.Refunds:\n\nRefunds  are not currently available once a transaction is successfully processed.\nPlease ensure that you review your purchase carefully before proceeding.',
      'vi':
          '3. Hoàn tiền và Hủy gói:\n\nViệc hoàn tiền  không khả dụng sau khi giao dịch được xử lý thành công.\nVui lòng đảm bảo rằng bạn xem xét kỹ giao dịch mua của mình trước khi tiếp tục.',
    },
    'y706e1gm': {
      'en':
          '4.Support and Assistance:\n\nIf you encounter any issues with your premium status activation or payment processing, please contact our support team via quangatse161692@fpt.edu.vn or 0775092217.\nOur team will strive to assist you and resolve any problems in a timely manner.',
      'vi':
          '4.Hỗ trợ khách hàng:\n\nNếu bạn gặp bất kỳ vấn đề nào với việc kích hoạt gói đăng ký hoặc quá trình thanh toán, vui lòng liên hệ với nhóm hỗ trợ của chúng tôi qua quangatse161692@fpt.edu.vn or 0775092217.\nNhóm của chúng tôi sẽ cố gắng hỗ trợ bạn và giải quyết mọi vấn đề một cách kịp thời.',
    },
    'eola6rr6': {
      'en':
          '5.Terms and Conditions Updates:\n\nThese terms and conditions are subject to change without prior notice.\nPlease refer to the latest version available on our website or within the app for the most up-to-date information.',
      'vi':
          '5.Cập nhật Điều khoản và Điều kiện:\n\nCác điều khoản và điều kiện này có thể thay đổi mà không cần thông báo trước.\nVui lòng tham khảo phiên bản mới nhất hiện có của chúng tôi hoặc trong ứng dụng để biết thông tin cập nhật sớm nhất.',
    },
    '4eb0dehh': {
      'en': 'Terms and conditions',
      'vi': 'Điều khoản và điều kiện chuyển khoản ngân hàng',
    },
    'akrzu1cb': {
      'en': 'Home',
      'vi': '',
    },
  },
  // BankChoice
  {
    '8o4b840a': {
      'en': 'Bank transfering with MB bank account',
      'vi': 'Chuyển khoản bằng tài khoản ngân hàng MB',
    },
    '3ntze840': {
      'en': 'Bank transfering with BIDV bank account',
      'vi': 'Chuyển khoản bằng tài khoản ngân hàng BIDV',
    },
    '6p0nic8b': {
      'en':
          'EatGreen\'s subcription payment terms and condition.\n\nBy using these payment methods you agree to our terms and conditions.',
      'vi':
          'Điều khoản và điều kiện thanh toán đăng ký gói của EatGreen.\n\nBằng cách sử dụng các phương thức thanh toán này, bạn đồng ý với các điều khoản và điều kiện của chúng tôi.',
    },
    'ho2bhf4n': {
      'en': 'Bank transfer',
      'vi': 'Chuyển khoản',
    },
    't15b1p4n': {
      'en': 'Home',
      'vi': '',
    },
  },
  // BIDVPayment
  {
    'mhfvlp3n': {
      'en': 'Important notes in subcribing premium using BIDV',
      'vi': 'Những lưu ý quan trọng khi đăng ký premium bằng BIDV',
    },
    'sdz2x550': {
      'en':
          ' 1. The content of transcation should be as the following:\n\n [gmail] - [subcription type] \n Ex: abc@gmail.com - 1 month',
      'vi':
          ' 1. Nội dung chuyển tiền phải theo mẫu như sau:\n\n [gmail người dùng] - [gói đăng ký]\n Ví dụ: abc@gmail.com - 1 tháng',
    },
    'ed2z8a5m': {
      'en':
          ' 2.Please ensure that you enter the correct amount when \nmaking a payment. \nThis will help to avoid any delays in\nprocessing your payment and returning any changes.\n1 month - 20000 VND/3 months - 50000 VND\n6 months - 90000 VND',
      'vi':
          '2.Hãy đảm bảo rằng bạn nhập đúng số \ntiền khi thanh toán.\nĐiều này sẽ giúp tránh bất kỳ sự chậm trễ trong \nxử lý thanh toán của bạn\nvà trả lại tiền thừa .\n1 tháng - 20000đ/3 tháng - 50000đ\n6 tháng - 90000 VNĐ',
    },
    'dc32r0ky': {
      'en': 'BIDV Payment',
      'vi': 'Thanh toán qua BIDV',
    },
    'rf2s6ha6': {
      'en': 'Home',
      'vi': '',
    },
  },
  // MBPayment
  {
    '3qs86kfi': {
      'en': 'Important notes in subcribing premium using MB',
      'vi': 'Những lưu ý quan trọng khi đăng ký premium bằng MB',
    },
    '0njscymk': {
      'en':
          ' 1. The content of transcation should be as the following:\n\n [gmail] - [subcription type] \n Ex: abc@gmail.com - 1 month',
      'vi':
          ' 1. Nội dung chuyển tiền phải theo mẫu như sau:\n\n [gmail người dùng] - [gói đăng ký]\n Ví dụ: abc@gmail.com - 1 tháng',
    },
    '1ntpmmvj': {
      'en':
          ' 2.Please ensure that you enter the correct amount when \nmaking a payment. \nThis will help to avoid any delays in\nprocessing your payment and returning any changes.\n1 month - 20000 VND/3 months - 50000 VND\n6 months - 90000 VND',
      'vi':
          '2.Hãy đảm bảo rằng bạn nhập đúng số \ntiền khi thanh toán.\nĐiều này sẽ giúp tránh bất kỳ sự chậm trễ trong \nxử lý thanh toán của bạn\nvà trả lại tiền thừa .\n1 tháng - 20000đ/3 tháng - 50000đ\n6 tháng - 90000 VNĐ',
    },
    'z5gihn1i': {
      'en': 'MB Payment',
      'vi': 'Thanh toán qua MB',
    },
    'e0g579ak': {
      'en': 'Home',
      'vi': '',
    },
  },
  // Support
  {
    '7j0580b4': {
      'en': 'Get support through our Facebook ',
      'vi': 'Hỗ trợ tư vấn qua Facebook',
    },
    '2vz1n3v7': {
      'en': 'Get support through our gmail:\nquangat161692@fpt.edu.vn',
      'vi': 'Hỗ trợ tư vấn qua gmail:\nquangat161692@fpt.edu.vn',
    },
    '1dmnv5o9': {
      'en': 'Get support through our phone number: \n0775092217 (if emergency)',
      'vi':
          'Nhận hỗ trợ qua số điện thoại của chúng tôi:\n0775092217 (nếu khẩn cấp)',
    },
    '5mb55l5n': {
      'en': 'Get support',
      'vi': 'Hỗ trợ khách hàng',
    },
    'h13ki1ig': {
      'en': 'Home',
      'vi': '',
    },
  },
  // Supportemail
  {
    'jfc4gzxm': {
      'en': 'Tell me your problem. \nPlease type here...',
      'vi': 'Cho tôi biết vấn đề của bạn.\nVui lòng nhập vào đây...',
    },
    '57l8ucus': {
      'en': 'Send email',
      'vi': 'Gửi email',
    },
    'ck8jecwq': {
      'en': 'Email support',
      'vi': 'Hỗ trợ email',
    },
    'zbwf8oz9': {
      'en': 'Home',
      'vi': 'Trang chủ',
    },
  },
  // userRating
  {
    'kl25jkih': {
      'en': 'Thanks for your rating !',
      'vi': 'Cảm ơn vì đánh giá của bạn !',
    },
    'qabmijcm': {
      'en': 'Close',
      'vi': 'Đóng',
    },
  },
  // userFeedback
  {
    '53yvdkc9': {
      'en': 'Thanks for your feedback !',
      'vi': 'Cảm ơn vì nhận xét của bạn !',
    },
    'aoc42mfk': {
      'en': 'Close',
      'vi': 'Đóng',
    },
  },
  // ChooseItems
  {
    'pn7mnmif': {
      'en': 'Choose foods',
      'vi': '',
    },
    'vsioz3ud': {
      'en': 'Foods',
      'vi': '',
    },
    'swzrskpt': {
      'en': 'Quanlity',
      'vi': '',
    },
    'sip0x0zv': {
      'en': 'Calories',
      'vi': '',
    },
    'lbetjm3e': {
      'en': 'Total: ',
      'vi': '',
    },
    'qmim0erz': {
      'en': 'cals',
      'vi': '',
    },
    'v23fdx90': {
      'en': 'Add',
      'vi': 'Thêm',
    },
  },
  // Miscellaneous
  {
    'duj9ph67': {
      'en': 'Next',
      'vi': '',
    },
    'ujhtgr0b': {
      'en': '50%',
      'vi': '',
    },
    'qu5qs676': {
      'en': '50%',
      'vi': '',
    },
    'sttg48ey': {
      'en': '',
      'vi': '',
    },
    'rxeluo3r': {
      'en': '',
      'vi': '',
    },
    'r7ja571c': {
      'en': '',
      'vi': '',
    },
    '4w1pk31d': {
      'en': '',
      'vi': '',
    },
    'ittn55re': {
      'en': '',
      'vi': '',
    },
    'ckclpjre': {
      'en': '',
      'vi': '',
    },
    'cw7lgrtv': {
      'en': '',
      'vi': '',
    },
    'il84umrm': {
      'en': '',
      'vi': '',
    },
    'cykgqqoi': {
      'en': '',
      'vi': '',
    },
    'jbq4bmst': {
      'en': '',
      'vi': '',
    },
    'hhxbxrew': {
      'en': '',
      'vi': '',
    },
    'vylsdjt7': {
      'en': '',
      'vi': '',
    },
    'zsr04uxt': {
      'en': '',
      'vi': '',
    },
    'fcn66rop': {
      'en': '',
      'vi': '',
    },
    'jqtpi17j': {
      'en': '',
      'vi': '',
    },
    '0xttofxq': {
      'en': '',
      'vi': '',
    },
    'axk3adyc': {
      'en': '',
      'vi': '',
    },
    'i2qsatxq': {
      'en': '',
      'vi': '',
    },
    'jqktam6v': {
      'en': '',
      'vi': '',
    },
    'r6egdkga': {
      'en': '',
      'vi': '',
    },
    'k6j5wa1u': {
      'en': '',
      'vi': '',
    },
    'yx0ekvnl': {
      'en': '',
      'vi': '',
    },
    '4cul6l7y': {
      'en': '',
      'vi': '',
    },
  },
].reduce((a, b) => a..addAll(b));
