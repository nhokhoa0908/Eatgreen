import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _myFlutterAppFamily = 'MyFlutterApp';
  static const String _myFlutterApp2Family = 'MyFlutterApp2';
  static const String _moMoIconFamily = 'MoMoIcon';
  static const String _bIDVIconFamily = 'BIDVIcon';
  static const String _mBIconFamily = 'MBIcon';

  // MyFlutterApp
  static const IconData kwaterFilled =
      IconData(0xe800, fontFamily: _myFlutterAppFamily);

  // MyFlutterApp2
  static const IconData kemptyWater =
      IconData(0xe801, fontFamily: _myFlutterApp2Family);

  // MoMo_icon
  static const IconData kmomoIcon =
      IconData(0xe802, fontFamily: _moMoIconFamily);

  // BIDV_icon
  static const IconData kbidvIcon =
      IconData(0xe800, fontFamily: _bIDVIconFamily);

  // MB_icon
  static const IconData kmbBankLogoInkythuatso0110090110 =
      IconData(0xe801, fontFamily: _mBIconFamily);
}
