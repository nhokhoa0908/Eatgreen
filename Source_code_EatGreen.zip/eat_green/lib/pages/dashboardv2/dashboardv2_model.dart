import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/request_manager.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';

class Dashboardv2Model extends FlutterFlowModel {
  ///  Local state fields for this page.

  int? waterindex = 0;

  bool isEmpty = true;

  bool isEmpty2 = true;

  bool isEmpty3 = true;

  bool? isEmpty4 = true;

  bool? isEmpty5 = true;

  bool? isEmpty6 = true;

  bool? isEmpty7 = true;

  bool? isEmpty8 = true;

  bool? isEmpty9 = true;

  bool? isEmpty10 = true;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  /// Query cache managers for this widget.

  final _waterManager = StreamRequestManager<List<UserDataRecord>>();
  Stream<List<UserDataRecord>> water({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Stream<List<UserDataRecord>> Function() requestFn,
  }) =>
      _waterManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearWaterCache() => _waterManager.clear();
  void clearWaterCacheKey(String? uniqueKey) =>
      _waterManager.clearRequest(uniqueKey);

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    unfocusNode.dispose();

    /// Dispose query cache managers for this widget.

    clearWaterCache();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
