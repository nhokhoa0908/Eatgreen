import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';
import 'dashboardv2_model.dart';
export 'dashboardv2_model.dart';

class Dashboardv2Widget extends StatefulWidget {
  const Dashboardv2Widget({Key? key}) : super(key: key);

  @override
  _Dashboardv2WidgetState createState() => _Dashboardv2WidgetState();
}

class _Dashboardv2WidgetState extends State<Dashboardv2Widget> {
  late Dashboardv2Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Dashboardv2Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return StreamBuilder<List<UserDataRecord>>(
      stream: _model.water(
        requestFn: () => queryUserDataRecord(
          parent: currentUserReference,
          singleRecord: true,
        ),
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        List<UserDataRecord> dashboardv2UserDataRecordList = snapshot.data!;
        // Return an empty Container when the item does not exist.
        if (snapshot.data!.isEmpty) {
          return Container();
        }
        final dashboardv2UserDataRecord =
            dashboardv2UserDataRecordList.isNotEmpty
                ? dashboardv2UserDataRecordList.first
                : null;
        return GestureDetector(
          onTap: () => FocusScope.of(context).requestFocus(_model.unfocusNode),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
              automaticallyImplyLeading: false,
              title: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    FFLocalizations.of(context).getText(
                      '55nxilzz' /* Dashboard */,
                    ),
                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                          fontFamily: 'Cookie',
                          color: Color(0xFF14141B),
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          useGoogleFonts: false,
                        ),
                  ),
                ],
              ),
              actions: [],
              centerTitle: false,
              elevation: 0.0,
            ),
            body: SafeArea(
              top: true,
              child: Stack(
                children: [
                  Container(
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: SingleChildScrollView(
                      primary: false,
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 48.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 0.0, 0.0, 0.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        FFLocalizations.of(context).getText(
                                          '34as36ct' /* Sleep time */,
                                        ),
                                        textAlign: TextAlign.start,
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                      LinearPercentIndicator(
                                        percent: 0.5,
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                0.45,
                                        lineHeight: 15.0,
                                        animation: true,
                                        progressColor: Color(0xFFFDD608),
                                        backgroundColor: Color(0xFF14141B),
                                        barRadius: Radius.circular(10.0),
                                        padding: EdgeInsets.zero,
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 15.0, 0.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        FFLocalizations.of(context).getText(
                                          'h2t4pd2v' /* Exercise time */,
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                      LinearPercentIndicator(
                                        percent: 0.5,
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                0.45,
                                        lineHeight: 15.0,
                                        animation: true,
                                        progressColor: Color(0xFFFF4040),
                                        backgroundColor: Color(0xFF1DD3D3),
                                        barRadius: Radius.circular(10.0),
                                        padding: EdgeInsets.zero,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 10.0, 10.0, 10.0),
                            child: Container(
                              width: double.infinity,
                              height: 395.0,
                              decoration: BoxDecoration(
                                color: Color(0xFF19FC82),
                                borderRadius: BorderRadius.circular(20.0),
                                border: Border.all(
                                  color: Colors.white,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Container(
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                0.5,
                                        height: 390.0,
                                        decoration: BoxDecoration(
                                          color: Color(0xFF19FC82),
                                          borderRadius:
                                              BorderRadius.circular(50.0),
                                        ),
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 0.0, 0.0, 5.0),
                                              child: Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'zet25kvr' /* Calories */,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Readex Pro',
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                              ),
                                            ),
                                            Container(
                                              width: 150.0,
                                              height: 300.0,
                                              child: custom_widgets
                                                  .VerticalProgressBar(
                                                width: 150.0,
                                                height: 300.0,
                                                progressValue: functions
                                                            .percentage(
                                                                valueOrDefault<
                                                                    double>(
                                                                  dashboardv2UserDataRecord
                                                                      ?.totalCalories,
                                                                  0.0,
                                                                ),
                                                                1695.0,
                                                                0.0)! >
                                                        1.0
                                                    ? 1.0
                                                    : functions.percentage(
                                                        valueOrDefault<double>(
                                                          dashboardv2UserDataRecord
                                                              ?.totalCalories,
                                                          0.0,
                                                        ),
                                                        1695.0,
                                                        0.0),
                                                progressColor:
                                                    Color(0xFF00FFFD),
                                                backgroundColor: Colors.white,
                                                combineText:
                                                    '${valueOrDefault<String>(
                                                  dashboardv2UserDataRecord
                                                      ?.totalCalories
                                                      ?.toString(),
                                                  '0',
                                                )}/1695',
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'm2mpbry8' /* Protein */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  fontWeight: FontWeight.bold,
                                                ),
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    10.0, 0.0, 0.0, 0.0),
                                            child: CircularPercentIndicator(
                                              percent: functions.percentage(
                                                          valueOrDefault<
                                                              double>(
                                                            dashboardv2UserDataRecord
                                                                ?.totalProtein,
                                                            0.0,
                                                          ),
                                                          80.0,
                                                          0.0)! >
                                                      1.0
                                                  ? 1.0
                                                  : functions.percentage(
                                                      valueOrDefault<double>(
                                                        dashboardv2UserDataRecord
                                                            ?.totalProtein,
                                                        0.0,
                                                      ),
                                                      80.0,
                                                      0.0)!,
                                              radius: 52.5,
                                              lineWidth: 15.0,
                                              animation: true,
                                              progressColor: Color(0xFFFF4040),
                                              backgroundColor:
                                                  FlutterFlowTheme.of(context)
                                                      .alternate,
                                              center: Text(
                                                '${valueOrDefault<String>(
                                                  dashboardv2UserDataRecord
                                                      ?.totalProtein
                                                      ?.toString(),
                                                  '0',
                                                )}/80',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .headlineSmall
                                                        .override(
                                                          fontFamily: 'Outfit',
                                                          fontSize: 16.0,
                                                          lineHeight: 1.5,
                                                        ),
                                              ),
                                              startAngle: 180.0,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 25.0, 0.0),
                                            child: Text(
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '5382dmox' /* Carbs */,
                                              ),
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily: 'Readex Pro',
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                            ),
                                          ),
                                          CircularPercentIndicator(
                                            percent: functions.percentage(
                                                        valueOrDefault<double>(
                                                          dashboardv2UserDataRecord
                                                              ?.totaCarb,
                                                          0.0,
                                                        ),
                                                        200.0,
                                                        0.0)! >
                                                    1.0
                                                ? 1.0
                                                : functions.percentage(
                                                    valueOrDefault<double>(
                                                      dashboardv2UserDataRecord
                                                          ?.totaCarb,
                                                      0.0,
                                                    ),
                                                    200.0,
                                                    0.0)!,
                                            radius: 52.5,
                                            lineWidth: 15.0,
                                            animation: true,
                                            progressColor: Color(0xFFFFE664),
                                            backgroundColor:
                                                FlutterFlowTheme.of(context)
                                                    .alternate,
                                            center: Text(
                                              '${valueOrDefault<String>(
                                                dashboardv2UserDataRecord
                                                    ?.totaCarb
                                                    ?.toString(),
                                                '0',
                                              )}/200',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .headlineSmall
                                                      .override(
                                                        fontFamily: 'Outfit',
                                                        fontSize: 16.0,
                                                        lineHeight: 1.5,
                                                      ),
                                            ),
                                            startAngle: 180.0,
                                          ),
                                        ],
                                      ),
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 40.0, 0.0),
                                            child: Text(
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '1g2g1ino' /* Fat */,
                                              ),
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily: 'Readex Pro',
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                            ),
                                          ),
                                          CircularPercentIndicator(
                                            percent: functions.percentage(
                                                        valueOrDefault<double>(
                                                          dashboardv2UserDataRecord
                                                              ?.totalFat,
                                                          0.0,
                                                        ),
                                                        55.0,
                                                        0.0)! >
                                                    1.0
                                                ? 1.0
                                                : functions.percentage(
                                                    valueOrDefault<double>(
                                                      dashboardv2UserDataRecord
                                                          ?.totalFat,
                                                      0.0,
                                                    ),
                                                    55.0,
                                                    0.0)!,
                                            radius: 52.5,
                                            lineWidth: 15.0,
                                            animation: true,
                                            progressColor: Color(0xFF23CA14),
                                            backgroundColor:
                                                FlutterFlowTheme.of(context)
                                                    .alternate,
                                            center: Text(
                                              '${valueOrDefault<String>(
                                                dashboardv2UserDataRecord
                                                    ?.totalFat
                                                    ?.toString(),
                                                '0',
                                              )}/55',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .headlineSmall
                                                      .override(
                                                        fontFamily: 'Outfit',
                                                        fontSize: 16.0,
                                                        lineHeight: 1.5,
                                                      ),
                                            ),
                                            startAngle: 180.0,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 10.0, 0.0, 0.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'i3b1s82k' /* Water */,
                                  ),
                                  textAlign: TextAlign.start,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'KGsolid',
                                        color: Color(0xFF00F3EB),
                                        fontSize: 18.0,
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FontStyle.italic,
                                        useGoogleFonts: false,
                                      ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 10.0, 10.0, 10.0),
                            child: Container(
                              width: double.infinity,
                              height: 200.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                                borderRadius: BorderRadius.circular(10.0),
                                border: Border.all(
                                  color: Color(0xFF00FF3A),
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty =
                                              !FFAppState().isEmpty);
                                          if (FFAppState().isEmpty) {
                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.2,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = false;
                                              FFAppState().isEmpty2 = false;
                                              FFAppState().isEmpty3 = false;
                                              FFAppState().isEmpty4 = false;
                                              FFAppState().isEmpty5 = false;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.0,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty2 =
                                              !FFAppState().isEmpty2);
                                          if (FFAppState().isEmpty2) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty3 = false;
                                              FFAppState().isEmpty4 = false;
                                              FFAppState().isEmpty5 = false;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.4,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty3 = false;
                                              FFAppState().isEmpty4 = false;
                                              FFAppState().isEmpty5 = false;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.2,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty2,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty3 =
                                              !FFAppState().isEmpty3);
                                          if (FFAppState().isEmpty3) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty4 = false;
                                              FFAppState().isEmpty5 = false;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.6,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty4 = false;
                                              FFAppState().isEmpty5 = false;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.4,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty3,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty4 =
                                              !FFAppState().isEmpty4);
                                          if (FFAppState().isEmpty4) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty5 = false;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.8,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty5 = false;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.6,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty4,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty5 =
                                              !FFAppState().isEmpty5);
                                          if (FFAppState().isEmpty5) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.0,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty6 = false;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 0.8,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty5,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty6 =
                                              !FFAppState().isEmpty6);
                                          if (FFAppState().isEmpty6) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.2,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty7 = false;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.0,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty6,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty7 =
                                              !FFAppState().isEmpty7);
                                          if (FFAppState().isEmpty7) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.4,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty8 = false;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.2,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty7,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty8 =
                                              !FFAppState().isEmpty8);
                                          if (FFAppState().isEmpty8) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty7 = true;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.6,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty7 = true;
                                              FFAppState().isEmpty9 = false;
                                              FFAppState().isEmpty10 = false;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.4,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty8,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() => FFAppState().isEmpty9 =
                                              !FFAppState().isEmpty9);
                                          if (FFAppState().isEmpty9) {
                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.8,
                                            ));
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty7 = true;
                                              FFAppState().isEmpty8 = true;
                                              FFAppState().isEmpty10 = false;
                                            });
                                          } else {
                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.6,
                                            ));
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty7 = true;
                                              FFAppState().isEmpty8 = true;
                                              FFAppState().isEmpty10 = false;
                                            });
                                          }
                                        },
                                        value: FFAppState().isEmpty9,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      ToggleIcon(
                                        onPressed: () async {
                                          setState(() =>
                                              FFAppState().isEmpty10 =
                                                  !FFAppState().isEmpty10);
                                          if (FFAppState().isEmpty10) {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty7 = true;
                                              FFAppState().isEmpty8 = true;
                                              FFAppState().isEmpty9 = true;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 2.0,
                                            ));
                                          } else {
                                            setState(() {
                                              FFAppState().isEmpty = true;
                                              FFAppState().isEmpty2 = true;
                                              FFAppState().isEmpty3 = true;
                                              FFAppState().isEmpty4 = true;
                                              FFAppState().isEmpty5 = true;
                                              FFAppState().isEmpty6 = true;
                                              FFAppState().isEmpty7 = true;
                                              FFAppState().isEmpty8 = true;
                                              FFAppState().isEmpty9 = true;
                                            });

                                            await dashboardv2UserDataRecord!
                                                .reference
                                                .update(
                                                    createUserDataRecordData(
                                              waterDrank: 1.8,
                                            ));
                                          }
                                        },
                                        value: FFAppState().isEmpty10,
                                        onIcon: Icon(
                                          FFIcons.kwaterFilled,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          size: 25.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons.kemptyWater,
                                          color: Color(0xFFE0E3E7),
                                          size: 25.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Text(
                                        FFLocalizations.of(context).getText(
                                          'aygaf8yp' /* Water */,
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              fontStyle: FontStyle.italic,
                                            ),
                                      ),
                                      Text(
                                        FFLocalizations.of(context).getText(
                                          '8ozaurmm' /* Goal: 2.0 L */,
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              fontStyle: FontStyle.italic,
                                            ),
                                      ),
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            valueOrDefault<String>(
                                              dashboardv2UserDataRecord
                                                  ?.waterDrank
                                                  ?.toString(),
                                              '0',
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  fontSize: 24.0,
                                                  fontStyle: FontStyle.italic,
                                                ),
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'oa67sgwd' /*  L */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  fontSize: 24.0,
                                                  fontStyle: FontStyle.italic,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            width: 365.0,
                            height: 58.0,
                            decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  blurRadius: 12.0,
                                  color: Color(0x33000000),
                                  offset: Offset(0.0, 5.0),
                                )
                              ],
                              gradient: LinearGradient(
                                colors: [Color(0xFF5AFA6E), Color(0xFFE0E3E7)],
                                stops: [0.0, 1.0],
                                begin: AlignmentDirectional(0.0, -1.0),
                                end: AlignmentDirectional(0, 1.0),
                              ),
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Icon(
                                  Icons.dashboard_outlined,
                                  color: Color(0xFF23CA14),
                                  size: 24.0,
                                ),
                                InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    context.pushNamed('ACTmain');
                                  },
                                  child: Icon(
                                    Icons.fitness_center,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    size: 24.0,
                                  ),
                                ),
                                InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    context.pushNamed('MenuMain');
                                  },
                                  child: Icon(
                                    Icons.food_bank_outlined,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    size: 24.0,
                                  ),
                                ),
                                Icon(
                                  Icons.insert_chart,
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  size: 24.0,
                                ),
                                InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    context.pushNamed('Setting');
                                  },
                                  child: Icon(
                                    Icons.settings_outlined,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    size: 24.0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
