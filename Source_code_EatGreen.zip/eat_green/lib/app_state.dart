import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static final FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  bool _ACTsearch = false;
  bool get ACTsearch => _ACTsearch;
  set ACTsearch(bool _value) {
    _ACTsearch = _value;
  }

  bool _ItemSearch = false;
  bool get ItemSearch => _ItemSearch;
  set ItemSearch(bool _value) {
    _ItemSearch = _value;
  }

  bool _isEmpty2 = false;
  bool get isEmpty2 => _isEmpty2;
  set isEmpty2(bool _value) {
    _isEmpty2 = _value;
  }

  bool _isEmpty = false;
  bool get isEmpty => _isEmpty;
  set isEmpty(bool _value) {
    _isEmpty = _value;
  }

  bool _isEmpty3 = false;
  bool get isEmpty3 => _isEmpty3;
  set isEmpty3(bool _value) {
    _isEmpty3 = _value;
  }

  bool _isEmpty4 = false;
  bool get isEmpty4 => _isEmpty4;
  set isEmpty4(bool _value) {
    _isEmpty4 = _value;
  }

  bool _isEmpty6 = false;
  bool get isEmpty6 => _isEmpty6;
  set isEmpty6(bool _value) {
    _isEmpty6 = _value;
  }

  bool _isEmpty9 = false;
  bool get isEmpty9 => _isEmpty9;
  set isEmpty9(bool _value) {
    _isEmpty9 = _value;
  }

  bool _isEmpty7 = false;
  bool get isEmpty7 => _isEmpty7;
  set isEmpty7(bool _value) {
    _isEmpty7 = _value;
  }

  bool _isEmpty8 = false;
  bool get isEmpty8 => _isEmpty8;
  set isEmpty8(bool _value) {
    _isEmpty8 = _value;
  }

  bool _isEmpty10 = false;
  bool get isEmpty10 => _isEmpty10;
  set isEmpty10(bool _value) {
    _isEmpty10 = _value;
  }

  bool _isEmpty5 = false;
  bool get isEmpty5 => _isEmpty5;
  set isEmpty5(bool _value) {
    _isEmpty5 = _value;
  }

  double _Totalactcalo = 0.0;
  double get Totalactcalo => _Totalactcalo;
  set Totalactcalo(double _value) {
    _Totalactcalo = _value;
  }

  double _Totalitemcalo = 0.0;
  double get Totalitemcalo => _Totalitemcalo;
  set Totalitemcalo(double _value) {
    _Totalitemcalo = _value;
  }

  double _Totalitempro = 0.0;
  double get Totalitempro => _Totalitempro;
  set Totalitempro(double _value) {
    _Totalitempro = _value;
  }

  double _Totalitemcarb = 0.0;
  double get Totalitemcarb => _Totalitemcarb;
  set Totalitemcarb(double _value) {
    _Totalitemcarb = _value;
  }

  double _Totalitemfat = 0.0;
  double get Totalitemfat => _Totalitemfat;
  set Totalitemfat(double _value) {
    _Totalitemfat = _value;
  }

  double _Sumitemcalo = 0.0;
  double get Sumitemcalo => _Sumitemcalo;
  set Sumitemcalo(double _value) {
    _Sumitemcalo = _value;
  }

  double _Sumitempro = 0.0;
  double get Sumitempro => _Sumitempro;
  set Sumitempro(double _value) {
    _Sumitempro = _value;
  }

  double _Sumitemcarb = 0.0;
  double get Sumitemcarb => _Sumitemcarb;
  set Sumitemcarb(double _value) {
    _Sumitemcarb = _value;
  }

  double _Sumitemfat = 0.0;
  double get Sumitemfat => _Sumitemfat;
  set Sumitemfat(double _value) {
    _Sumitemfat = _value;
  }

  bool _premium = false;
  bool get premium => _premium;
  set premium(bool _value) {
    _premium = _value;
  }

  double _Totalitemcalo2 = 0.0;
  double get Totalitemcalo2 => _Totalitemcalo2;
  set Totalitemcalo2(double _value) {
    _Totalitemcalo2 = _value;
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
