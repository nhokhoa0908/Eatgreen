// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your widget name, define your parameter, and then add the
// boilerplate code using the button on the right!

import 'dart:math';

class RandomMealprep extends StatefulWidget {
  const RandomMealprep({
    Key? key,
    this.width,
    this.height,
  }) : super(key: key);

  final double? width;
  final double? height;

  @override
  _RandomMealprepState createState() => _RandomMealprepState();
}

class _RandomMealprepState extends State<RandomMealprep> {
  List<MenuItem> menuItems = [
    MenuItem(food: 'Bánh mì trắng - 2 lát', calories: 133, isVegan: true),
    MenuItem(food: 'Trứng', calories: 74, isVegan: false),
    MenuItem(food: 'Ngũ cốc Fruit Loops', calories: 110, isVegan: true),
    MenuItem(food: 'Salad trái cây', calories: 177, isVegan: true),
    MenuItem(food: 'Sữa chua', calories: 208, isVegan: false),
    MenuItem(food: 'Mì miso', calories: 160, isVegan: false),
    MenuItem(food: 'Phở', calories: 219, isVegan: false),
    MenuItem(food: 'Bánh mì burger', calories: 272, isVegan: false),
    MenuItem(food: 'Bánh mì thập cẩm', calories: 504, isVegan: false),
    MenuItem(food: 'Cơm tấm', calories: 600, isVegan: false),
    MenuItem(food: 'Cơm tấm chay', calories: 520, isVegan: true),
    MenuItem(food: 'Sandwich beacon', calories: 520, isVegan: false),
    MenuItem(food: 'Bún bò', calories: 534, isVegan: false),
    MenuItem(food: 'Bánh ướt', calories: 590, isVegan: false),
    MenuItem(food: 'Mì quảng', calories: 415, isVegan: false),
    MenuItem(food: 'Sữa (100ml)', calories: 50, isVegan: false),
    MenuItem(food: 'Nước trái cây (100ml)', calories: 55, isVegan: true),
    MenuItem(food: 'Cà phê (100ml)', calories: 20, isVegan: true),
    MenuItem(food: 'Cà phê sữa (100ml)', calories: 200, isVegan: false),
    MenuItem(food: 'Các loại hạt (100g)', calories: 500, isVegan: true),
    // Add more menu items as needed
  ];

  List<MenuItem> filteredMenuItems = [];

  @override
  void initState() {
    super.initState();
    filteredMenuItems = _generateValidMenu();
  }

  void resetMenu() {
    setState(() {
      filteredMenuItems = _generateValidMenu();
    });
  }

  List<MenuItem> _generateValidMenu() {
    List<MenuItem> validMenuItems = [];
    Random random = Random();
    int totalCalories = 0;

    while (totalCalories < 400 || totalCalories > 600) {
      validMenuItems.clear();
      totalCalories = 0;

      for (int i = 0; i < menuItems.length; i++) {
        if (random.nextBool() &&
            (menuItems[i].isVegan || !menuItems[i].isVegan)) {
          validMenuItems.add(menuItems[i]);
          totalCalories += menuItems[i].calories;
        }
      }
    }

    return validMenuItems;
  }

  @override
  Widget build(BuildContext context) {
    int totalCalories =
        filteredMenuItems.fold(0, (sum, item) => sum + item.calories);

    return Container(
      width: widget.width,
      height: widget.height,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Recommend Breakfast',
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.teal.withOpacity(0.1), Colors.transparent],
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'Food',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Calories',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Type',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.teal.withOpacity(0.1), Colors.transparent],
                ),
              ),
              child: ListView.builder(
                itemCount: filteredMenuItems.length,
                itemBuilder: (context, index) {
                  final menuItem = filteredMenuItems[index];
                  return ListTile(
                    tileColor: Colors.white,
                    title: Text(menuItem.food),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment
                          .center, // Aligns content to the center
                      children: [
                        Text(
                          '${menuItem.calories} cal',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 10),
                        GestureDetector(
                          onTap: () {
                            final type =
                                menuItem.isVegan ? 'Vegan' : 'Non-Vegan';
                            final tooltip = 'Type: $type';
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(tooltip),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          },
                          child: Icon(
                            menuItem.isVegan ? Icons.eco : Icons.set_meal,
                            color: menuItem.isVegan ? Colors.green : Colors.red,
                            size: 18,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: resetMenu,
                  child: Text('Reset'),
                ),
                Text(
                  'Total Calories:',
                  style: TextStyle(
                    color: Colors.yellow,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  '$totalCalories cal',
                  style: TextStyle(
                    color: Colors.yellow,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MenuItem {
  final String food;
  final int calories;
  final bool isVegan;

  MenuItem({required this.food, required this.calories, required this.isVegan});
}
