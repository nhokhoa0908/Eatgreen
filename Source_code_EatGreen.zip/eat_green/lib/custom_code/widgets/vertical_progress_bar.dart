// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class VerticalProgressBar extends StatefulWidget {
  const VerticalProgressBar({
    Key? key,
    this.width,
    this.height,
    this.progressValue,
    this.progressColor,
    this.backgroundColor,
    this.combineText,
  }) : super(key: key);

  final double? width; // width: 40
  final double? height; // height: 340
  final double?
      progressValue; // show 0 to 1.0 value same as 0% to 100% capacity of progress
  final Color? progressColor; // color: 5dc890
  final Color? backgroundColor; // color: white
  final String? combineText; // text in the middle [value]/1695

  @override
  _VerticalProgressBarState createState() => _VerticalProgressBarState();
}

class _VerticalProgressBarState extends State<VerticalProgressBar> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              color: widget.backgroundColor ?? Colors.white,
              borderRadius: BorderRadius.circular(
                  20), // Adjust the value to change the roundness
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: FractionallySizedBox(
              alignment: Alignment.bottomCenter,
              heightFactor: widget.progressValue ?? 0.0,
              child: Container(
                decoration: BoxDecoration(
                  color: widget.progressColor ?? Color(0xFF5DC890),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              widget.combineText ?? '',
              style: TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
