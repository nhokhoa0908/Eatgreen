import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'get_started_model.dart';
export 'get_started_model.dart';

class GetStartedWidget extends StatefulWidget {
  const GetStartedWidget({Key? key}) : super(key: key);

  @override
  _GetStartedWidgetState createState() => _GetStartedWidgetState();
}

class _GetStartedWidgetState extends State<GetStartedWidget>
    with TickerProviderStateMixin {
  late GetStartedModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = {
    'containerOnPageLoadAnimation1': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1.ms),
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 400.ms,
          begin: 0.0,
          end: 1.0,
        ),
        ScaleEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 400.ms,
          begin: Offset(3.0, 3.0),
          end: Offset(1.0, 1.0),
        ),
      ],
    ),
    'containerOnPageLoadAnimation2': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 300.ms),
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 300.ms,
          duration: 300.ms,
          begin: 0.0,
          end: 1.0,
        ),
        ScaleEffect(
          curve: Curves.bounceOut,
          delay: 300.ms,
          duration: 300.ms,
          begin: Offset(0.6, 0.6),
          end: Offset(1.0, 1.0),
        ),
      ],
    ),
    'textOnPageLoadAnimation1': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 350.ms),
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 350.ms,
          duration: 400.ms,
          begin: 0.0,
          end: 1.0,
        ),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 350.ms,
          duration: 400.ms,
          begin: Offset(0.0, 30.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'textOnPageLoadAnimation2': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 400.ms),
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 400.ms,
          duration: 400.ms,
          begin: 0.0,
          end: 1.0,
        ),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 400.ms,
          duration: 400.ms,
          begin: Offset(0.0, 30.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
  };

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GetStartedModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (FFAppState().isEmpty == null) {
        await UserDataRecord.createDoc(currentUserReference!)
            .set(createUserDataRecordData(
          waterDrank: 0.0,
        ));

        await FeedbackRecord.createDoc(currentUserReference!)
            .set(createFeedbackRecordData(
          createdBy: valueOrDefault<String>(
            currentUserUid,
            '0',
          ),
          content: null,
          createdAt: null,
        ));
      }
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_model.unfocusNode),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        body: Align(
          alignment: AlignmentDirectional(0.0, 0.0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
                  height: MediaQuery.sizeOf(context).height * 0.1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFF23CA14),
                        Color(0xFF5DC890),
                        Colors.white
                      ],
                      stops: [0.0, 0.5, 1.0],
                      begin: AlignmentDirectional(-1.0, -1.0),
                      end: AlignmentDirectional(1.0, 1.0),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 120.0,
                        height: 120.0,
                        decoration: BoxDecoration(
                          color: Color(0xFF5DC890),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Color(0xFF003100),
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 8.0, 8.0, 8.0),
                          child: Image.asset(
                            'assets/images/icon_logo.png',
                            width: 300.0,
                            height: 300.0,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ).animateOnPageLoad(
                          animationsMap['containerOnPageLoadAnimation2']!),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 44.0, 0.0, 0.0),
                        child: Text(
                          FFLocalizations.of(context).getText(
                            'tcqjt0e4' /* Welcome! */,
                          ),
                          style: FlutterFlowTheme.of(context)
                              .displaySmall
                              .override(
                                fontFamily: 'Plus Jakarta Sans',
                                color: Color(0xFF101213),
                                fontSize: 36.0,
                                fontWeight: FontWeight.w600,
                              ),
                        ).animateOnPageLoad(
                            animationsMap['textOnPageLoadAnimation1']!),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            44.0, 8.0, 44.0, 20.0),
                        child: Text(
                          valueOrDefault<String>(
                            functions.quoteGenerator(),
                            '\"The journey of a thousand miles begins with a single step. - Lao Tzu\" ',
                          ),
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'Plus Jakarta Sans',
                                    color: Color(0xFF57636C),
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ).animateOnPageLoad(
                            animationsMap['textOnPageLoadAnimation2']!),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 50.0, 16.0, 44.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Expanded(
                              child: Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      8.0, 0.0, 0.0, 16.0),
                                  child: StreamBuilder<List<UserDataRecord>>(
                                    stream: queryUserDataRecord(
                                      parent: currentUserReference,
                                      singleRecord: true,
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 50.0,
                                            height: 50.0,
                                            child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                FlutterFlowTheme.of(context)
                                                    .primary,
                                              ),
                                            ),
                                          ),
                                        );
                                      }
                                      List<UserDataRecord>
                                          buttonUserDataRecordList =
                                          snapshot.data!;
                                      // Return an empty Container when the item does not exist.
                                      if (snapshot.data!.isEmpty) {
                                        return Container();
                                      }
                                      final buttonUserDataRecord =
                                          buttonUserDataRecordList.isNotEmpty
                                              ? buttonUserDataRecordList.first
                                              : null;
                                      return FFButtonWidget(
                                        onPressed: () async {
                                          if (valueOrDefault(
                                                      currentUserDocument
                                                          ?.menuChoice,
                                                      '') !=
                                                  null &&
                                              valueOrDefault(
                                                      currentUserDocument
                                                          ?.menuChoice,
                                                      '') !=
                                                  '') {
                                            context.pushNamed('dashboardv2');

                                            if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                0.0) {
                                              setState(() {
                                                FFAppState().isEmpty = false;
                                                FFAppState().isEmpty2 = false;
                                                FFAppState().isEmpty3 = false;
                                                FFAppState().isEmpty4 = false;
                                                FFAppState().isEmpty5 = false;
                                                FFAppState().isEmpty6 = false;
                                                FFAppState().isEmpty7 = false;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                0.2) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = false;
                                                FFAppState().isEmpty3 = false;
                                                FFAppState().isEmpty4 = false;
                                                FFAppState().isEmpty5 = false;
                                                FFAppState().isEmpty6 = false;
                                                FFAppState().isEmpty7 = false;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                0.4) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = false;
                                                FFAppState().isEmpty4 = false;
                                                FFAppState().isEmpty5 = false;
                                                FFAppState().isEmpty6 = false;
                                                FFAppState().isEmpty7 = false;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                0.6) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = false;
                                                FFAppState().isEmpty5 = false;
                                                FFAppState().isEmpty6 = false;
                                                FFAppState().isEmpty7 = false;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                0.8) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = true;
                                                FFAppState().isEmpty5 = false;
                                                FFAppState().isEmpty6 = false;
                                                FFAppState().isEmpty7 = false;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                1.0) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = true;
                                                FFAppState().isEmpty5 = true;
                                                FFAppState().isEmpty6 = false;
                                                FFAppState().isEmpty7 = false;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                1.2) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = true;
                                                FFAppState().isEmpty5 = true;
                                                FFAppState().isEmpty6 = true;
                                                FFAppState().isEmpty7 = false;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                1.4) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = true;
                                                FFAppState().isEmpty5 = true;
                                                FFAppState().isEmpty6 = true;
                                                FFAppState().isEmpty7 = true;
                                                FFAppState().isEmpty8 = false;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                1.6) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = true;
                                                FFAppState().isEmpty5 = true;
                                                FFAppState().isEmpty6 = true;
                                                FFAppState().isEmpty7 = true;
                                                FFAppState().isEmpty8 = true;
                                                FFAppState().isEmpty9 = false;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                1.8) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = true;
                                                FFAppState().isEmpty5 = true;
                                                FFAppState().isEmpty6 = true;
                                                FFAppState().isEmpty7 = true;
                                                FFAppState().isEmpty8 = true;
                                                FFAppState().isEmpty9 = true;
                                                FFAppState().isEmpty10 = false;
                                              });
                                            } else if (buttonUserDataRecord
                                                    ?.waterDrank ==
                                                2.0) {
                                              setState(() {
                                                FFAppState().isEmpty = true;
                                                FFAppState().isEmpty2 = true;
                                                FFAppState().isEmpty3 = true;
                                                FFAppState().isEmpty4 = true;
                                                FFAppState().isEmpty5 = true;
                                                FFAppState().isEmpty6 = true;
                                                FFAppState().isEmpty7 = true;
                                                FFAppState().isEmpty8 = true;
                                                FFAppState().isEmpty9 = true;
                                                FFAppState().isEmpty10 = true;
                                              });
                                            }
                                          } else {
                                            context.pushNamed('LanguageOp');
                                          }
                                        },
                                        text:
                                            FFLocalizations.of(context).getText(
                                          '888xxcd6' /* Next */,
                                        ),
                                        options: FFButtonOptions(
                                          width: 230.0,
                                          height: 52.0,
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          iconPadding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          color: Color(0xFF5DC890),
                                          textStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .override(
                                                    fontFamily:
                                                        'Plus Jakarta Sans',
                                                    color: Colors.white,
                                                    fontSize: 16.0,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                          elevation: 3.0,
                                          borderSide: BorderSide(
                                            color: Colors.transparent,
                                            width: 1.0,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(12.0),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ).animateOnPageLoad(
                    animationsMap['containerOnPageLoadAnimation1']!),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
