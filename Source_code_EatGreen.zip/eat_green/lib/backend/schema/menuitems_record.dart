import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MenuitemsRecord extends FirestoreRecord {
  MenuitemsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "item_name" field.
  String? _itemName;
  String get itemName => _itemName ?? '';
  bool hasItemName() => _itemName != null;

  // "item_photo" field.
  String? _itemPhoto;
  String get itemPhoto => _itemPhoto ?? '';
  bool hasItemPhoto() => _itemPhoto != null;

  // "item_calories" field.
  int? _itemCalories;
  int get itemCalories => _itemCalories ?? 0;
  bool hasItemCalories() => _itemCalories != null;

  // "item_carbohydrate" field.
  double? _itemCarbohydrate;
  double get itemCarbohydrate => _itemCarbohydrate ?? 0.0;
  bool hasItemCarbohydrate() => _itemCarbohydrate != null;

  // "item_protein" field.
  double? _itemProtein;
  double get itemProtein => _itemProtein ?? 0.0;
  bool hasItemProtein() => _itemProtein != null;

  // "item_fat" field.
  double? _itemFat;
  double get itemFat => _itemFat ?? 0.0;
  bool hasItemFat() => _itemFat != null;

  void _initializeFields() {
    _itemName = snapshotData['item_name'] as String?;
    _itemPhoto = snapshotData['item_photo'] as String?;
    _itemCalories = castToType<int>(snapshotData['item_calories']);
    _itemCarbohydrate = castToType<double>(snapshotData['item_carbohydrate']);
    _itemProtein = castToType<double>(snapshotData['item_protein']);
    _itemFat = castToType<double>(snapshotData['item_fat']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('menuitems');

  static Stream<MenuitemsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MenuitemsRecord.fromSnapshot(s));

  static Future<MenuitemsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MenuitemsRecord.fromSnapshot(s));

  static MenuitemsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MenuitemsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MenuitemsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MenuitemsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MenuitemsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MenuitemsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMenuitemsRecordData({
  String? itemName,
  String? itemPhoto,
  int? itemCalories,
  double? itemCarbohydrate,
  double? itemProtein,
  double? itemFat,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'item_name': itemName,
      'item_photo': itemPhoto,
      'item_calories': itemCalories,
      'item_carbohydrate': itemCarbohydrate,
      'item_protein': itemProtein,
      'item_fat': itemFat,
    }.withoutNulls,
  );

  return firestoreData;
}

class MenuitemsRecordDocumentEquality implements Equality<MenuitemsRecord> {
  const MenuitemsRecordDocumentEquality();

  @override
  bool equals(MenuitemsRecord? e1, MenuitemsRecord? e2) {
    return e1?.itemName == e2?.itemName &&
        e1?.itemPhoto == e2?.itemPhoto &&
        e1?.itemCalories == e2?.itemCalories &&
        e1?.itemCarbohydrate == e2?.itemCarbohydrate &&
        e1?.itemProtein == e2?.itemProtein &&
        e1?.itemFat == e2?.itemFat;
  }

  @override
  int hash(MenuitemsRecord? e) => const ListEquality().hash([
        e?.itemName,
        e?.itemPhoto,
        e?.itemCalories,
        e?.itemCarbohydrate,
        e?.itemProtein,
        e?.itemFat
      ]);

  @override
  bool isValidKey(Object? o) => o is MenuitemsRecord;
}
