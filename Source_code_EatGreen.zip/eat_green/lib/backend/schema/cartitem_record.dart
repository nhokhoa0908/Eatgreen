import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CartitemRecord extends FirestoreRecord {
  CartitemRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "itemname" field.
  String? _itemname;
  String get itemname => _itemname ?? '';
  bool hasItemname() => _itemname != null;

  // "itemcalories" field.
  double? _itemcalories;
  double get itemcalories => _itemcalories ?? 0.0;
  bool hasItemcalories() => _itemcalories != null;

  // "itemscount" field.
  int? _itemscount;
  int get itemscount => _itemscount ?? 0;
  bool hasItemscount() => _itemscount != null;

  // "itempro" field.
  double? _itempro;
  double get itempro => _itempro ?? 0.0;
  bool hasItempro() => _itempro != null;

  // "itemcarb" field.
  double? _itemcarb;
  double get itemcarb => _itemcarb ?? 0.0;
  bool hasItemcarb() => _itemcarb != null;

  // "itemfat" field.
  double? _itemfat;
  double get itemfat => _itemfat ?? 0.0;
  bool hasItemfat() => _itemfat != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _itemname = snapshotData['itemname'] as String?;
    _itemcalories = castToType<double>(snapshotData['itemcalories']);
    _itemscount = castToType<int>(snapshotData['itemscount']);
    _itempro = castToType<double>(snapshotData['itempro']);
    _itemcarb = castToType<double>(snapshotData['itemcarb']);
    _itemfat = castToType<double>(snapshotData['itemfat']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('cartitem')
          : FirebaseFirestore.instance.collectionGroup('cartitem');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('cartitem').doc();

  static Stream<CartitemRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CartitemRecord.fromSnapshot(s));

  static Future<CartitemRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CartitemRecord.fromSnapshot(s));

  static CartitemRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CartitemRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CartitemRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CartitemRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CartitemRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CartitemRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCartitemRecordData({
  String? itemname,
  double? itemcalories,
  int? itemscount,
  double? itempro,
  double? itemcarb,
  double? itemfat,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'itemname': itemname,
      'itemcalories': itemcalories,
      'itemscount': itemscount,
      'itempro': itempro,
      'itemcarb': itemcarb,
      'itemfat': itemfat,
    }.withoutNulls,
  );

  return firestoreData;
}

class CartitemRecordDocumentEquality implements Equality<CartitemRecord> {
  const CartitemRecordDocumentEquality();

  @override
  bool equals(CartitemRecord? e1, CartitemRecord? e2) {
    return e1?.itemname == e2?.itemname &&
        e1?.itemcalories == e2?.itemcalories &&
        e1?.itemscount == e2?.itemscount &&
        e1?.itempro == e2?.itempro &&
        e1?.itemcarb == e2?.itemcarb &&
        e1?.itemfat == e2?.itemfat;
  }

  @override
  int hash(CartitemRecord? e) => const ListEquality().hash([
        e?.itemname,
        e?.itemcalories,
        e?.itemscount,
        e?.itempro,
        e?.itemcarb,
        e?.itemfat
      ]);

  @override
  bool isValidKey(Object? o) => o is CartitemRecord;
}
