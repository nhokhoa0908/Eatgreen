import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserDataRecord extends FirestoreRecord {
  UserDataRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "water_drank" field.
  double? _waterDrank;
  double get waterDrank => _waterDrank ?? 0.0;
  bool hasWaterDrank() => _waterDrank != null;

  // "totalCalories" field.
  double? _totalCalories;
  double get totalCalories => _totalCalories ?? 0.0;
  bool hasTotalCalories() => _totalCalories != null;

  // "totalProtein" field.
  double? _totalProtein;
  double get totalProtein => _totalProtein ?? 0.0;
  bool hasTotalProtein() => _totalProtein != null;

  // "totalFat" field.
  double? _totalFat;
  double get totalFat => _totalFat ?? 0.0;
  bool hasTotalFat() => _totalFat != null;

  // "totaCarb" field.
  double? _totaCarb;
  double get totaCarb => _totaCarb ?? 0.0;
  bool hasTotaCarb() => _totaCarb != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _waterDrank = castToType<double>(snapshotData['water_drank']);
    _totalCalories = castToType<double>(snapshotData['totalCalories']);
    _totalProtein = castToType<double>(snapshotData['totalProtein']);
    _totalFat = castToType<double>(snapshotData['totalFat']);
    _totaCarb = castToType<double>(snapshotData['totaCarb']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('user_data')
          : FirebaseFirestore.instance.collectionGroup('user_data');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('user_data').doc();

  static Stream<UserDataRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UserDataRecord.fromSnapshot(s));

  static Future<UserDataRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UserDataRecord.fromSnapshot(s));

  static UserDataRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UserDataRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UserDataRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UserDataRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UserDataRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UserDataRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUserDataRecordData({
  double? waterDrank,
  double? totalCalories,
  double? totalProtein,
  double? totalFat,
  double? totaCarb,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'water_drank': waterDrank,
      'totalCalories': totalCalories,
      'totalProtein': totalProtein,
      'totalFat': totalFat,
      'totaCarb': totaCarb,
    }.withoutNulls,
  );

  return firestoreData;
}

class UserDataRecordDocumentEquality implements Equality<UserDataRecord> {
  const UserDataRecordDocumentEquality();

  @override
  bool equals(UserDataRecord? e1, UserDataRecord? e2) {
    return e1?.waterDrank == e2?.waterDrank &&
        e1?.totalCalories == e2?.totalCalories &&
        e1?.totalProtein == e2?.totalProtein &&
        e1?.totalFat == e2?.totalFat &&
        e1?.totaCarb == e2?.totaCarb;
  }

  @override
  int hash(UserDataRecord? e) => const ListEquality().hash([
        e?.waterDrank,
        e?.totalCalories,
        e?.totalProtein,
        e?.totalFat,
        e?.totaCarb
      ]);

  @override
  bool isValidKey(Object? o) => o is UserDataRecord;
}
