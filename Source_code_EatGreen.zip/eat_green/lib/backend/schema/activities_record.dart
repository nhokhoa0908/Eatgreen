import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ActivitiesRecord extends FirestoreRecord {
  ActivitiesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "activity_name" field.
  String? _activityName;
  String get activityName => _activityName ?? '';
  bool hasActivityName() => _activityName != null;

  // "activity_photo" field.
  String? _activityPhoto;
  String get activityPhoto => _activityPhoto ?? '';
  bool hasActivityPhoto() => _activityPhoto != null;

  // "activity_calories" field.
  double? _activityCalories;
  double get activityCalories => _activityCalories ?? 0.0;
  bool hasActivityCalories() => _activityCalories != null;

  void _initializeFields() {
    _activityName = snapshotData['activity_name'] as String?;
    _activityPhoto = snapshotData['activity_photo'] as String?;
    _activityCalories = castToType<double>(snapshotData['activity_calories']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('activities');

  static Stream<ActivitiesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ActivitiesRecord.fromSnapshot(s));

  static Future<ActivitiesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ActivitiesRecord.fromSnapshot(s));

  static ActivitiesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ActivitiesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ActivitiesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ActivitiesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ActivitiesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ActivitiesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createActivitiesRecordData({
  String? activityName,
  String? activityPhoto,
  double? activityCalories,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'activity_name': activityName,
      'activity_photo': activityPhoto,
      'activity_calories': activityCalories,
    }.withoutNulls,
  );

  return firestoreData;
}

class ActivitiesRecordDocumentEquality implements Equality<ActivitiesRecord> {
  const ActivitiesRecordDocumentEquality();

  @override
  bool equals(ActivitiesRecord? e1, ActivitiesRecord? e2) {
    return e1?.activityName == e2?.activityName &&
        e1?.activityPhoto == e2?.activityPhoto &&
        e1?.activityCalories == e2?.activityCalories;
  }

  @override
  int hash(ActivitiesRecord? e) => const ListEquality()
      .hash([e?.activityName, e?.activityPhoto, e?.activityCalories]);

  @override
  bool isValidKey(Object? o) => o is ActivitiesRecord;
}
