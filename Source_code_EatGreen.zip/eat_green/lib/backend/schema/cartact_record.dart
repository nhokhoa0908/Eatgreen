import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CartactRecord extends FirestoreRecord {
  CartactRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "actname" field.
  String? _actname;
  String get actname => _actname ?? '';
  bool hasActname() => _actname != null;

  // "actcalories" field.
  double? _actcalories;
  double get actcalories => _actcalories ?? 0.0;
  bool hasActcalories() => _actcalories != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _actname = snapshotData['actname'] as String?;
    _actcalories = castToType<double>(snapshotData['actcalories']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('cartact')
          : FirebaseFirestore.instance.collectionGroup('cartact');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('cartact').doc();

  static Stream<CartactRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CartactRecord.fromSnapshot(s));

  static Future<CartactRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CartactRecord.fromSnapshot(s));

  static CartactRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CartactRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CartactRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CartactRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CartactRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CartactRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCartactRecordData({
  String? actname,
  double? actcalories,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'actname': actname,
      'actcalories': actcalories,
    }.withoutNulls,
  );

  return firestoreData;
}

class CartactRecordDocumentEquality implements Equality<CartactRecord> {
  const CartactRecordDocumentEquality();

  @override
  bool equals(CartactRecord? e1, CartactRecord? e2) {
    return e1?.actname == e2?.actname && e1?.actcalories == e2?.actcalories;
  }

  @override
  int hash(CartactRecord? e) =>
      const ListEquality().hash([e?.actname, e?.actcalories]);

  @override
  bool isValidKey(Object? o) => o is CartactRecord;
}
