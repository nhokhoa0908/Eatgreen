import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAJt5oyRCav4mUlUsGX_AKNXS8gw144zsc",
            authDomain: "flutter-fitness-2f06f.firebaseapp.com",
            projectId: "flutter-fitness-2f06f",
            storageBucket: "flutter-fitness-2f06f.appspot.com",
            messagingSenderId: "817438763148",
            appId: "1:817438763148:web:74180648af91324fdf73a9"));
  } else {
    await Firebase.initializeApp();
  }
}
